// Background script
chrome.runtime.onInstalled.addListener(() => {
    console.log('LocalStorage Manager Extension installed successfully');
    
    // Set default badge text
    chrome.action.setBadgeText({ text: 'LS' });
    chrome.action.setBadgeBackgroundColor({ color: '#000000' });
  });
  
  // Handle extension icon click
  chrome.action.onClicked.addListener(async (tab) => {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          chrome.runtime.sendMessage({ action: 'toggle-menu' });
        }
      });
    } catch (error) {
      console.error('Script injection failed:', error);
      // Try to notify user about the error
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==',
        title: 'LocalStorage Manager',
        message: 'Cannot inject script on this page. Try on a regular website.'
      });
    }
  });