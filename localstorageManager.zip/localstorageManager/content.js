
let modMenu = null;
let isMinimized = false;
let isDragging = false;
let currentX = 0;
let currentY = 0;
let initialX = 0;
let initialY = 0;
let currentGroupForStorage = null;

function createModMenu() {
  if (modMenu) return;

  modMenu = document.createElement('div');
  modMenu.id = 'localStorage-manager';
  modMenu.innerHTML = `
    <div class="mod-menu-header" id="mod-menu-header">
      <span class="title">📦 LocalStorage Manager</span>
      <div class="controls">
        <button id="minimize-btn">−</button>
        <button id="close-btn">×</button>
      </div>
    </div>
    <div class="mod-menu-content" id="mod-menu-content">
      <div class="tabs">
        <button class="tab-btn active" data-tab="groups">Groups</button>
        <button class="tab-btn" data-tab="sites">Sites</button>
      </div>
      
      <div class="tab-content active" id="groups-tab">
        <div class="section">
          <h3>🗂️ LocalStorage Groups</h3>
          <div class="input-group">
            <input type="text" id="group-name" placeholder="Tên group">
            <input type="text" id="group-desc" placeholder="Mô tả">
            <button id="add-group">Thêm Group</button>
          </div>
          <div id="groups-list"></div>
        </div>
        
        <div class="section" id="add-storage-section" style="display: none;">
          <h3>📝 Thêm LocalStorage</h3>
          <div class="storage-form">
            <input type="text" id="storage-name" placeholder="Tên localStorage">
            <textarea id="storage-data" placeholder='Nhập localStorage JSON data...
Ví dụ: {"token":"abc123","userId":"456"}'></textarea>
            <div class="form-actions">
              <button id="save-storage">Lưu</button>
              <button id="cancel-storage" class="cancel-btn">Hủy</button>
            </div>
          </div>
        </div>
      </div>
      
      <div class="tab-content" id="sites-tab">
        <div class="section">
          <h3>🌐 Quick Sites</h3>
          <div class="input-group">
            <input type="text" id="site-url" placeholder="URL (https://...)">
            <input type="text" id="site-label" placeholder="Label">
            <button id="add-site">Thêm Site</button>
          </div>
          <div id="sites-list"></div>
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(modMenu);
  setupEventListeners();
  loadData();
}

// Setup event listeners
function setupEventListeners() {
  const header = document.getElementById('mod-menu-header');
  const minimizeBtn = document.getElementById('minimize-btn');
  const closeBtn = document.getElementById('close-btn');

  // Dragging functionality
  header.addEventListener('mousedown', startDrag);
  document.addEventListener('mousemove', drag);
  document.addEventListener('mouseup', endDrag);

  // Controls
  minimizeBtn.addEventListener('click', toggleMinimize);
  closeBtn.addEventListener('click', closeMenu);

  // Tabs
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', switchTab);
  });

  // Groups
  document.getElementById('add-group').addEventListener('click', addGroup);
  
  // Storage form
  document.getElementById('save-storage').addEventListener('click', saveStorage);
  document.getElementById('cancel-storage').addEventListener('click', cancelStorage);
  
  // Sites
  document.getElementById('add-site').addEventListener('click', addSite);

  // Event delegation for dynamic buttons
  document.addEventListener('click', handleButtonClick);
}

// Handle all button clicks with event delegation
function handleButtonClick(e) {
  const button = e.target.closest('button[data-action]');
  if (!button) return;

  e.preventDefault();
  e.stopPropagation();

  const action = button.dataset.action;
  const groupName = button.dataset.group;
  const index = button.dataset.index;
  const url = button.dataset.url;

  switch (action) {
    case 'add-storage':
      addLocalStorageToGroup(groupName);
      break;
    case 'edit-group':
      editGroup(groupName);
      break;
    case 'delete-group':
      deleteGroup(groupName);
      break;
    case 'set-storage':
      setLocalStorage(groupName, parseInt(index));
      break;
    case 'edit-storage':
      editStorageItem(groupName, parseInt(index));
      break;
    case 'delete-storage':
      deleteStorageItem(groupName, parseInt(index));
      break;
    case 'open-site':
      openSite(url);
      break;
    case 'go-site':
      goToSite(url);
      break;
    case 'edit-site':
      editSite(parseInt(index));
      break;
    case 'delete-site':
      deleteSite(parseInt(index));
      break;
  }
}

// Drag functionality
function startDrag(e) {
  isDragging = true;
  initialX = e.clientX - currentX;
  initialY = e.clientY - currentY;
  if (modMenu) modMenu.style.cursor = 'grabbing';
}

function drag(e) {
  if (!isDragging) return;
  e.preventDefault();
  currentX = e.clientX - initialX;
  currentY = e.clientY - initialY;
  if (modMenu) {
    modMenu.style.transform = `translate(${currentX}px, ${currentY}px)`;
  }
}

function endDrag() {
  isDragging = false;
  if (modMenu) modMenu.style.cursor = '';
}

// Controls
function toggleMinimize() {
  const content = document.getElementById('mod-menu-content');
  if (!content) return;
  
  isMinimized = !isMinimized;
  content.style.display = isMinimized ? 'none' : 'block';
  document.getElementById('minimize-btn').textContent = isMinimized ? '+' : '−';
  
  if (modMenu) {
    modMenu.style.width = isMinimized ? '200px' : '350px';
  }
}

function closeMenu() {
  if (modMenu) {
    modMenu.remove();
    modMenu = null;
  }
}

// Tab switching
function switchTab(e) {
  const tabName = e.target.dataset.tab;
  
  // Ẩn form add storage khi chuyển tab
  cancelStorage();
  
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
  
  e.target.classList.add('active');
  const targetTab = document.getElementById(`${tabName}-tab`);
  if (targetTab) {
    targetTab.classList.add('active');
  }
}

// Groups functionality
async function addGroup() {
  const nameInput = document.getElementById('group-name');
  const descInput = document.getElementById('group-desc');
  
  if (!nameInput || !descInput) return;
  
  const name = nameInput.value.trim();
  const desc = descInput.value.trim();
  
  if (!name) {
    alert('Vui lòng nhập tên group!');
    return;
  }
  
  const groups = await getStorageData('groups') || {};
  
  if (groups[name]) {
    alert('Group này đã tồn tại!');
    return;
  }
  
  groups[name] = { description: desc, items: [] };
  
  await setStorageData('groups', groups);
  nameInput.value = '';
  descInput.value = '';
  loadGroups();
  showNotification('Đã tạo group thành công!', 'success');
}

async function loadGroups() {
  const groups = await getStorageData('groups') || {};
  const container = document.getElementById('groups-list');
  
  if (!container) return;
  
  if (Object.keys(groups).length === 0) {
    container.innerHTML = '<div class="empty-state">Chưa có group nào. Tạo group đầu tiên!</div>';
    return;
  }
  
  container.innerHTML = Object.keys(groups).map(name => {
    const safeName = encodeURIComponent(name);
    const safeDesc = groups[name].description || 'Không có mô tả';
    
    return `
    <div class="group-item">
      <div class="group-header">
        <div class="group-title">
          <div class="group-name">${escapeHtml(name)}</div>
          <div class="group-desc">${escapeHtml(safeDesc)}</div>
        </div>
        <div class="group-actions">
          <button data-action="add-storage" data-group="${safeName}" title="Thêm localStorage">📝</button>
          <button data-action="edit-group" data-group="${safeName}" title="Sửa group">✏️</button>
          <button data-action="delete-group" data-group="${safeName}" title="Xóa group">🗑️</button>
        </div>
      </div>
      <div class="group-items">
        ${groups[name].items.length === 0 ? 
          '<div style="color: #999; font-style: italic; font-size: 10px;">Chưa có localStorage nào</div>' :
          groups[name].items.map((item, index) => `
            <div class="storage-item">
              <span class="item-preview" title="${escapeHtml(item.name)}">${escapeHtml(item.name || 'Item ' + (index + 1))}</span>
              <div class="item-actions">
                <button data-action="set-storage" data-group="${safeName}" data-index="${index}" title="Áp dụng localStorage">Set</button>
                <button data-action="edit-storage" data-group="${safeName}" data-index="${index}" title="Sửa">✏️</button>
                <button data-action="delete-storage" data-group="${safeName}" data-index="${index}" title="Xóa">❌</button>
              </div>
            </div>
          `).join('')
        }
      </div>
    </div>
    `;
  }).join('');
}

// Storage functionality
function addLocalStorageToGroup(groupName) {
  currentGroupForStorage = decodeURIComponent(groupName);
  const section = document.getElementById('add-storage-section');
  const nameInput = document.getElementById('storage-name');
  const dataInput = document.getElementById('storage-data');
  
  if (section && nameInput && dataInput) {
    section.style.display = 'block';
    nameInput.value = '';
    dataInput.value = '';
    nameInput.focus();
    section.scrollIntoView({ behavior: 'smooth' });
  }
}

async function saveStorage() {
  if (!currentGroupForStorage) return;
  
  const nameInput = document.getElementById('storage-name');
  const dataInput = document.getElementById('storage-data');
  
  if (!nameInput || !dataInput) return;
  
  const name = nameInput.value.trim();
  const data = dataInput.value.trim();
  
  if (!name || !data) {
    alert('Vui lòng nhập đầy đủ tên và dữ liệu!');
    return;
  }
  
  try {
    const parsed = JSON.parse(data);
    const groups = await getStorageData('groups') || {};
    
    if (!groups[currentGroupForStorage]) {
      alert('Group không tồn tại!');
      return;
    }
    
    groups[currentGroupForStorage].items.push({ name, data: parsed });
    await setStorageData('groups', groups);
    
    cancelStorage();
    loadGroups();
    showNotification('Đã lưu localStorage thành công!', 'success');
  } catch (e) {
    alert('Dữ liệu JSON không hợp lệ! Vui lòng kiểm tra lại.\n\nLỗi: ' + e.message);
  }
}

function cancelStorage() {
  currentGroupForStorage = null;
  const section = document.getElementById('add-storage-section');
  if (section) {
    section.style.display = 'none';
  }
}

// Sites functionality
async function addSite() {
  const urlInput = document.getElementById('site-url');
  const labelInput = document.getElementById('site-label');
  
  if (!urlInput || !labelInput) return;
  
  const url = urlInput.value.trim();
  const label = labelInput.value.trim();
  
  if (!url || !label) {
    alert('Vui lòng nhập đầy đủ URL và Label!');
    return;
  }
  
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    alert('URL phải bắt đầu bằng http:// hoặc https://');
    return;
  }
  
  const sites = await getStorageData('sites') || [];
  sites.push({ url, label });
  
  await setStorageData('sites', sites);
  urlInput.value = '';
  labelInput.value = '';
  loadSites();
  showNotification('Đã thêm site thành công!', 'success');
}

async function loadSites() {
  const sites = await getStorageData('sites') || [];
  const container = document.getElementById('sites-list');
  
  if (!container) return;
  
  if (sites.length === 0) {
    container.innerHTML = '<div class="empty-state">Chưa có site nào. Thêm site đầu tiên!</div>';
    return;
  }
  
  container.innerHTML = sites.map((site, index) => {
    const safeUrl = encodeURIComponent(site.url);
    return `
    <div class="site-item">
      <div class="site-info">
        <div class="site-title">
          <div class="site-label">${escapeHtml(site.label)}</div>
          <div class="site-url" title="${escapeHtml(site.url)}">${escapeHtml(site.url)}</div>
        </div>
        <div class="site-actions">
          <button data-action="open-site" data-url="${safeUrl}" title="Mở tab mới">🔗</button>
          <button data-action="go-site" data-url="${safeUrl}" title="Chuyển hướng">➤</button>
          <button data-action="edit-site" data-index="${index}" title="Sửa">✏️</button>
          <button data-action="delete-site" data-index="${index}" title="Xóa">🗑️</button>
        </div>
      </div>
    </div>
    `;
  }).join('');
}

// Action functions
async function setLocalStorage(groupName, itemIndex) {
  const decodedGroupName = decodeURIComponent(groupName);
  const groups = await getStorageData('groups') || {};
  const item = groups[decodedGroupName] && groups[decodedGroupName].items[itemIndex];
  
  if (!item) {
    alert('Không tìm thấy localStorage item!');
    return;
  }
  
  if (!confirm(`Áp dụng localStorage "${item.name}"?\n\nLưu ý: Tất cả localStorage hiện tại sẽ bị xóa và thay thế.`)) {
    return;
  }
  
  try {
    // Clear current localStorage
    localStorage.clear();
    
    // Set new localStorage
    Object.keys(item.data).forEach(key => {
      const value = item.data[key];
      localStorage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value));
    });
    
    showNotification('LocalStorage đã được áp dụng thành công!', 'success');
    
    // Reload page after 1 second
    setTimeout(() => {
      location.reload();
    }, 1000);
  } catch (e) {
    alert('Lỗi khi áp dụng localStorage: ' + e.message);
  }
}

async function deleteGroup(groupName) {
  const decodedGroupName = decodeURIComponent(groupName);
  if (!confirm(`Xóa group "${decodedGroupName}" và tất cả localStorage bên trong?`)) return;
  
  const groups = await getStorageData('groups') || {};
  delete groups[decodedGroupName];
  await setStorageData('groups', groups);
  loadGroups();
  showNotification('Đã xóa group!', 'success');
}

async function deleteStorageItem(groupName, itemIndex) {
  const decodedGroupName = decodeURIComponent(groupName);
  const groups = await getStorageData('groups') || {};
  const itemName = groups[decodedGroupName] && groups[decodedGroupName].items[itemIndex] && groups[decodedGroupName].items[itemIndex].name || 'Item';
  
  if (!confirm(`Xóa localStorage "${itemName}"?`)) return;
  
  if (groups[decodedGroupName] && groups[decodedGroupName].items) {
    groups[decodedGroupName].items.splice(itemIndex, 1);
    await setStorageData('groups', groups);
    loadGroups();
    showNotification('Đã xóa localStorage item!', 'success');
  }
}

async function editGroup(groupName) {
  const decodedGroupName = decodeURIComponent(groupName);
  const groups = await getStorageData('groups') || {};
  const group = groups[decodedGroupName];
  
  if (!group) return;
  
  const newName = prompt('Tên group mới:', decodedGroupName);
  const newDesc = prompt('Mô tả mới:', group.description);
  
  if (newName && newName !== decodedGroupName) {
    if (groups[newName]) {
      alert('Tên group đã tồn tại!');
      return;
    }
    groups[newName] = { ...group, description: newDesc || '' };
    delete groups[decodedGroupName];
  } else if (newDesc !== null) {
    group.description = newDesc;
  } else {
    return;
  }
  
  await setStorageData('groups', groups);
  loadGroups();
  showNotification('Đã cập nhật group!', 'success');
}

async function editStorageItem(groupName, itemIndex) {
  const decodedGroupName = decodeURIComponent(groupName);
  const groups = await getStorageData('groups') || {};
  const item = groups[decodedGroupName] && groups[decodedGroupName].items[itemIndex];
  
  if (!item) return;
  
  const newName = prompt('Tên mới:', item.name);
  const newData = prompt('JSON data mới:', JSON.stringify(item.data, null, 2));
  
  if (newName !== null && newData !== null) {
    try {
      const parsed = JSON.parse(newData);
      groups[decodedGroupName].items[itemIndex] = { name: newName, data: parsed };
      await setStorageData('groups', groups);
      loadGroups();
      showNotification('Đã cập nhật localStorage item!', 'success');
    } catch (e) {
      alert('JSON không hợp lệ: ' + e.message);
    }
  }
}

function openSite(url) {
  const decodedUrl = decodeURIComponent(url);
  window.open(decodedUrl, '_blank');
}

function goToSite(url) {
  const decodedUrl = decodeURIComponent(url);
  window.location.href = decodedUrl;
}

async function editSite(index) {
  const sites = await getStorageData('sites') || [];
  const site = sites[index];
  
  if (!site) return;
  
  const newLabel = prompt('Label mới:', site.label);
  const newUrl = prompt('URL mới:', site.url);
  
  if (newLabel !== null && newUrl !== null) {
    if (!newUrl.startsWith('http://') && !newUrl.startsWith('https://')) {
      alert('URL phải bắt đầu bằng http:// hoặc https://');
      return;
    }
    sites[index] = { label: newLabel, url: newUrl };
    await setStorageData('sites', sites);
    loadSites();
    showNotification('Đã cập nhật site!', 'success');
  }
}

async function deleteSite(index) {
  const sites = await getStorageData('sites') || [];
  const siteName = sites[index] && sites[index].label || 'Site';
  
  if (!confirm(`Xóa site "${siteName}"?`)) return;
  
  sites.splice(index, 1);
  await setStorageData('sites', sites);
  loadSites();
  showNotification('Đã xóa site!', 'success');
}

// Utility functions
async function getStorageData(key) {
  return new Promise(resolve => {
    chrome.storage.local.get([key], result => {
      resolve(result[key]);
    });
  });
}

async function setStorageData(key, value) {
  return new Promise(resolve => {
    chrome.storage.local.set({ [key]: value }, resolve);
  });
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.style.cssText = `
    position: fixed;
    top: 80px;
    right: 20px;
    background: ${type === 'success' ? '#4CAF50' : '#2196F3'};
    color: white;
    padding: 10px 15px;
    border-radius: 4px;
    z-index: 1000000;
    font-family: 'Segoe UI', sans-serif;
    font-size: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
  `;
  notification.textContent = message;
  document.body.appendChild(notification);
  
  setTimeout(() => {
    if (notification.parentNode) {
      notification.remove();
    }
  }, 3000);
}

async function loadData() {
  // Load default sites if not exists
  const existingSites = await getStorageData('sites');
  if (!existingSites || existingSites.length === 0) {
    const defaultSites = [
      { url: 'https://www.ugphone.com/toc-portal/#/dashboard/index', label: 'UGPHONE' },
      { url: 'https://cloud.vsphone.com/', label: 'VSPHONE' },
      { url: 'https://cloud.vmoscloud.com/', label: 'VMOS' },
      { url: 'https://www.cloudemulator.net/app/?utm_source=web&utm_medium=organic&utm_campaign=organic', label: 'REDFINGER' }
    ];
    await setStorageData('sites', defaultSites);
  }
  
  loadGroups();
  loadSites();
}

// Initialize when page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', createModMenu);
} else {
  createModMenu();
}

// Listen for messages from popup/background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'toggle-menu') {
    if (modMenu) {
      closeMenu();
    } else {
      createModMenu();
    }
  }
});